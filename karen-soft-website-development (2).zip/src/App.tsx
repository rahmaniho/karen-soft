import { useEffect, useState } from "react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Features } from "./components/Features";
import { Modules } from "./components/Modules";
import { CtaBand } from "./components/CtaBand";
import { Pricing } from "./components/Pricing";
import { Testimonials } from "./components/Testimonials";
import { About } from "./components/About";
import { Faq } from "./components/Faq";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { Icon } from "./components/Icons";
import { CONTACT } from "./data/site";
import { cn } from "./utils/cn";

function FloatingActions() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      className={cn(
        "fixed bottom-5 left-5 z-50 flex flex-col items-center gap-3 transition-all duration-500",
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0",
      )}
    >
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        aria-label="بازگشت به بالا"
        className="grid h-11 w-11 cursor-pointer place-items-center rounded-full border border-white/10 bg-ink-900/90 text-slate-300 backdrop-blur transition hover:text-gold-300"
      >
        <Icon name="arrowLeft" className="h-5 w-5 rotate-90" />
      </button>
      <a
        href={CONTACT.tel}
        aria-label={`تماس با ${CONTACT.phoneFa}`}
        className="animate-pulse-ring grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950 shadow-xl transition hover:scale-105"
      >
        <Icon name="phone" className="h-6 w-6" strokeWidth={1.8} />
      </a>
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-ink-950 antialiased">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <Modules />
        <CtaBand />
        <Pricing />
        <Testimonials />
        <About />
        <Faq />
        <Contact />
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
