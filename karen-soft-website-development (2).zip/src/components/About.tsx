import { Icon } from "./Icons";
import { KarenMark } from "./Logo";
import { Reveal } from "./Reveal";
import { SERVICES, STEPS } from "../data/site";

export function About() {
  return (
    <section
      id="about"
      className="relative overflow-hidden border-y border-white/5 bg-gradient-to-b from-ink-950 via-brand-900/20 to-ink-950 py-20 md:py-28"
    >
      <div className="grid-bg absolute inset-0 -z-10 opacity-25" />
      <div className="absolute top-0 right-1/4 -z-10 h-80 w-80 rounded-full bg-brand-500/15 blur-[130px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <Reveal>
            <div className="mb-4 flex items-center gap-3">
              <span className="h-px w-8 bg-gradient-to-l from-transparent to-brand-400" />
              <span className="text-xs font-bold tracking-[0.25em] text-brand-300 uppercase">
                درباره کارن سافت
              </span>
            </div>
            <h2 className="text-3xl leading-tight font-black text-white sm:text-4xl">
              نرم‌افزار تخصصی، ساخته‌شده برای
              <span className="bg-gradient-to-l from-brand-300 to-brand-500 bg-clip-text text-transparent">
                {" "}
                کسب‌وکار ایرانی
              </span>
            </h2>
            <p className="mt-5 leading-9 text-slate-300/85">
              <strong className="text-white">کارن سافت</strong> یک شرکت نرم‌افزاری با تمرکز بر
              طراحی و توسعه سامانه‌های تخصصی سازمانی است. ما با شناخت دقیق فرایندهای کاری مشتریان،
              نرم‌افزارهایی می‌سازیم که واقعاً استفاده می‌شوند: ساده، سریع، امن و کاملاً فارسی.
            </p>
            <p className="mt-4 leading-9 text-slate-300/70">
              محصول شاخص ما، <strong className="text-gold-300">دفتر وکالت هوشمند</strong>، حاصل
              سال‌ها همکاری نزدیک با وکلا و مؤسسات حقوقی است؛ نرم‌افزاری که نظم، سرعت و شفافیت مالی
              را به دفتر شما می‌آورد.
            </p>

            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {SERVICES.map((s) => (
                <div
                  key={s.title}
                  className="group rounded-xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-brand-400/40 hover:bg-brand-500/5"
                >
                  <div className="mb-2 flex items-center gap-2.5">
                    <span className="grid h-9 w-9 place-items-center rounded-lg bg-brand-500/15 text-brand-300 transition group-hover:scale-110">
                      <Icon name={s.icon} className="h-4.5 w-4.5" />
                    </span>
                    <span className="text-sm font-black text-white">{s.title}</span>
                  </div>
                  <p className="text-[12px] leading-6 text-slate-400">{s.desc}</p>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal delay={150}>
            <div className="relative mx-auto max-w-md">
              <div className="absolute -inset-6 -z-10 rounded-full bg-brand-500/12 blur-3xl" />
              <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-transparent p-8 text-center backdrop-blur">
                <KarenMark className="mx-auto h-28 w-28 drop-shadow-[0_6px_24px_rgba(27,124,224,0.55)]" />
                <div className="mt-5 text-2xl font-black text-white">کارن سافت</div>
                <div className="mt-1 text-xs font-bold tracking-[0.4em] text-brand-300 uppercase">
                  Karensoft
                </div>
                <div className="mx-auto my-6 h-px w-2/3 gold-line opacity-50" />
                <p className="text-sm leading-8 text-slate-300/80">
                  «اطلاعات شما، سرمایه اعتماد ماست.»
                </p>
              </div>

              {/* مراحل همکاری */}
              <div className="mt-8 space-y-3">
                {STEPS.map((step, i) => (
                  <div
                    key={step.title}
                    className="flex items-start gap-3 rounded-xl border border-white/8 bg-ink-900/60 p-3.5"
                  >
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-gold-400 to-gold-600 text-xs font-black text-ink-950">
                      {(i + 1).toLocaleString("fa-IR")}
                    </span>
                    <div>
                      <div className="text-sm font-black text-white">{step.title}</div>
                      <div className="mt-0.5 text-[12px] leading-6 text-slate-400">{step.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
