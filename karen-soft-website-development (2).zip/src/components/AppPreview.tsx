import type { ReactElement } from "react";
import { Icon, type IconName } from "./Icons";
import type { ModuleView } from "../data/site";
import { cn } from "../utils/cn";

const MENU: { id: ModuleView | string; label: string; icon: IconName }[] = [
  { id: "home", label: "داشبورد", icon: "home" },
  { id: "dashboard", label: "پرونده‌ها", icon: "briefcase" },
  { id: "clients", label: "موکلین", icon: "users" },
  { id: "sessions", label: "جلسات", icon: "calendar" },
  { id: "tasks", label: "وظایف", icon: "clipboard" },
  { id: "contracts", label: "قراردادها", icon: "file" },
  { id: "finance", label: "مالی", icon: "wallet" },
  { id: "reports", label: "گزارش‌ها", icon: "chart" },
  { id: "settings", label: "تنظیمات", icon: "settings" },
];

function Donut({
  segments,
}: {
  segments: { value: number; color: string; label: string }[];
}) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;

  return (
    <div className="flex items-center gap-4">
      <svg viewBox="0 0 100 100" className="h-28 w-28 -rotate-90">
        {segments.map((seg, i) => {
          const len = (seg.value / total) * circumference;
          const el = (
            <circle
              key={i}
              cx="50"
              cy="50"
              r={radius}
              fill="none"
              stroke={seg.color}
              strokeWidth="13"
              strokeDasharray={`${len} ${circumference - len}`}
              strokeDashoffset={-offset}
              strokeLinecap="butt"
            />
          );
          offset += len;
          return el;
        })}
      </svg>
      <ul className="space-y-1.5 text-[11px] text-slate-600">
        {segments.map((s) => (
          <li key={s.label} className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
            <span className="font-semibold text-slate-700">{s.label}</span>
            <span className="text-slate-400">{s.value}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function LineChart({
  series,
}: {
  series: { color: string; points: number[]; label: string; fill?: string }[];
}) {
  const w = 280;
  const h = 110;
  const max = Math.max(...series.flatMap((s) => s.points)) * 1.15;
  const toPath = (points: number[]) =>
    points
      .map((p, i) => {
        const x = (i / (points.length - 1)) * w;
        const y = h - (p / max) * h;
        return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(" ");

  return (
    <div>
      <svg viewBox={`0 0 ${w} ${h + 14}`} className="w-full">
        {[0.25, 0.5, 0.75, 1].map((g) => (
          <line
            key={g}
            x1="0"
            x2={w}
            y1={h - g * h}
            y2={h - g * h}
            stroke="#e2e8f0"
            strokeWidth="1"
            strokeDasharray="3 4"
          />
        ))}
        {series.map((s) => (
          <g key={s.label}>
            {s.fill && (
              <path
                d={`${toPath(s.points)} L${w},${h} L0,${h} Z`}
                fill={s.fill}
                opacity="0.18"
              />
            )}
            <path
              d={toPath(s.points)}
              fill="none"
              stroke={s.color}
              strokeWidth="2.4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            {s.points.map((p, i) => (
              <circle
                key={i}
                cx={(i / (s.points.length - 1)) * w}
                cy={h - (p / max) * h}
                r="2.6"
                fill="#fff"
                stroke={s.color}
                strokeWidth="2"
              />
            ))}
          </g>
        ))}
      </svg>
      <div className="mt-1 flex justify-between px-1 text-[9px] text-slate-400">
        {["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور"].map((m) => (
          <span key={m}>{m}</span>
        ))}
      </div>
    </div>
  );
}

function Bars({ data }: { data: { label: string; value: number }[] }) {
  const max = Math.max(...data.map((d) => d.value));
  return (
    <div className="flex h-32 items-end justify-between gap-2 px-1">
      {data.map((d) => (
        <div key={d.label} className="flex flex-1 flex-col items-center gap-1.5">
          <div
            className="w-full rounded-t-md bg-gradient-to-t from-amber-500 to-amber-300"
            style={{ height: `${(d.value / max) * 100}%` }}
          />
          <span className="text-[9px] text-slate-500">{d.label}</span>
        </div>
      ))}
    </div>
  );
}

function Kpi({
  label,
  value,
  hint,
  tone = "slate",
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "slate" | "emerald" | "rose" | "amber";
}) {
  const tones = {
    slate: "text-slate-800",
    emerald: "text-emerald-600",
    rose: "text-rose-600",
    amber: "text-amber-600",
  };
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-2.5 shadow-sm">
      <div className="text-[10px] font-medium text-slate-500">{label}</div>
      <div className={cn("mt-1 text-sm font-black sm:text-base", tones[tone])}>{value}</div>
      {hint && <div className="mt-0.5 text-[9px] text-slate-400">{hint}</div>}
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
      <div className="mb-2 text-[11px] font-bold text-slate-700">{title}</div>
      {children}
    </div>
  );
}

const statusChip: Record<string, string> = {
  "در جریان": "bg-amber-100 text-amber-700",
  مختومه: "bg-emerald-100 text-emerald-700",
  فعال: "bg-emerald-100 text-emerald-700",
  "در حال اجرا": "bg-sky-100 text-sky-700",
  "تکمیل شده": "bg-slate-200 text-slate-600",
  "سررسید گذشته": "bg-rose-100 text-rose-700",
};

function Table({
  head,
  rows,
}: {
  head: string[];
  rows: (string | { chip: string })[][];
}) {
  return (
    <div className="overflow-x-auto rounded-lg border border-slate-200">
      <table className="w-full min-w-[280px] text-right text-[10px]">
        <thead className="bg-slate-50 text-slate-500">
          <tr>
            {head.map((h) => (
              <th key={h} className="px-2 py-1.5 font-semibold whitespace-nowrap">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 bg-white">
          {rows.map((r, i) => (
            <tr key={i} className="text-slate-600">
              {r.map((cell, j) => (
                <td key={j} className="px-2 py-1.5 whitespace-nowrap">
                  {typeof cell === "string" ? (
                    cell
                  ) : (
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[9px] font-bold",
                        statusChip[cell.chip] ?? "bg-slate-100 text-slate-600",
                      )}
                    >
                      {cell.chip}
                    </span>
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ViewDashboard() {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-2">
        <Kpi label="کل پرونده‌ها" value="۱۲۶" hint="+۸ این ماه" />
        <Kpi label="کل موکلین" value="۸۹" hint="+۵ این ماه" />
        <Kpi label="جلسات امروز" value="۷" tone="amber" hint="۲ جلسه دادگاه" />
        <Kpi label="دریافت‌ها" value="۲.۴۸ میلیارد" tone="emerald" hint="+۱۲٪ نسبت به ماه قبل" />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Panel title="نمودار درآمد و هزینه">
          <LineChart
            series={[
              { label: "درآمد", color: "#10b981", fill: "#10b981", points: [8, 12, 10, 16, 14, 20] },
              { label: "هزینه", color: "#f43f5e", points: [4, 6, 5, 8, 6, 9] },
            ]}
          />
        </Panel>
        <Panel title="نمودار وضعیت پرونده‌ها">
          <Donut
            segments={[
              { label: "در جریان", value: 61, color: "#2563eb" },
              { label: "مختومه", value: 28, color: "#10b981" },
              { label: "ارجاع شده", value: 15, color: "#f43f5e" },
              { label: "بایگانی", value: 22, color: "#38bdf8" },
            ]}
          />
        </Panel>
      </div>
      <Panel title="پرونده‌های اخیر">
        <Table
          head={["عنوان پرونده", "موکل", "شعبه", "وضعیت"]}
          rows={[
            ["مطالبه وجه چک", "شرکت پارس تجارت", "شعبه ۱۳ حقوقی", { chip: "در جریان" }],
            ["خسارت قراردادی", "آقای محمدی", "شعبه ۳ حقوقی", { chip: "در جریان" }],
            ["الزام به تنظیم سند", "خانم رضایی", "شعبه ۱ حقوقی", { chip: "مختومه" }],
            ["طلاق توافقی", "آقای کریمی", "شعبه خانواده", { chip: "در جریان" }],
          ]}
        />
      </Panel>
    </div>
  );
}

function ViewClients() {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-xs font-bold text-slate-700">موکلین</div>
        <div className="rounded-lg bg-slate-900 px-2.5 py-1 text-[10px] font-bold text-white">
          + افزودن موکل
        </div>
      </div>
      <Table
        head={["نام موکل", "تلفن همراه", "پرونده‌ها", "آخرین فعالیت"]}
        rows={[
          ["شرکت پارس تجارت", "۰۹۱۲*****۴۶", "۳", "۱۴۰۳/۰۳/۱۵"],
          ["آقای علی محمدی", "۰۹۱۵*****۲۲", "۲", "۱۴۰۳/۰۳/۱۳"],
          ["خانم مریم رضایی", "۰۹۱۲*****۹۱", "۱", "۱۴۰۳/۰۳/۱۲"],
          ["آقای حسین کریمی", "۰۹۳۵*****۰۷", "۲", "۱۴۰۳/۰۳/۱۰"],
        ]}
      />
      <div className="grid grid-cols-2 gap-2">
        <Panel title="جلسات آتی">
          <ul className="space-y-1.5 text-[10px]">
            {[
              ["جلسه دادگاه", "شعبه ۱۲ حقوقی", "۱۴۰۳/۰۳/۲۲ — ۱۰:۰۰"],
              ["مشاوره موکل", "دفتر وکالت", "۱۴۰۳/۰۳/۲۳ — ۱۳:۰۰"],
              ["ملاقات موکل", "دفتر وکالت", "۱۴۰۳/۰۳/۲۵ — ۱۶:۳۰"],
            ].map(([a, b, c]) => (
              <li
                key={c}
                className="flex items-center justify-between rounded-lg bg-slate-50 px-2 py-1.5"
              >
                <span className="font-bold text-slate-700">{a}</span>
                <span className="text-slate-500">{b}</span>
                <span className="text-slate-400">{c}</span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="خرداد ۱۴۰۳">
          <div className="grid grid-cols-7 gap-1 text-center text-[9px] text-slate-500">
            {["ش", "ی", "د", "س", "چ", "پ", "ج"].map((d) => (
              <span key={d} className="font-bold text-slate-400">
                {d}
              </span>
            ))}
            {Array.from({ length: 28 }, (_, i) => i + 1).map((d) => (
              <span
                key={d}
                className={cn(
                  "rounded py-0.5",
                  d === 22
                    ? "bg-amber-500 font-bold text-white"
                    : [8, 15, 25].includes(d)
                      ? "bg-amber-100 text-amber-700"
                      : "text-slate-500",
                )}
              >
                {d.toLocaleString("fa-IR")}
              </span>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

function ViewFinance() {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-2">
        <Kpi label="کل درآمدها" value="۲,۴۸۰,۰۰۰,۰۰۰" tone="emerald" hint="+۱۲٪ نسبت به ماه قبل" />
        <Kpi label="کل هزینه‌ها" value="۷۸۵,۰۰۰,۰۰۰" tone="rose" hint="-۵٪ نسبت به ماه قبل" />
        <Kpi label="حق‌الوکاله دریافتی" value="۱,۳۰۵,۰۰۰,۰۰۰" tone="amber" />
        <Kpi label="مانده حساب" value="۱,۶۹۵,۰۰۰,۰۰۰" />
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div className="col-span-2">
          <Panel title="نمودار روند مالی">
            <LineChart
              series={[
                {
                  label: "درآمدها",
                  color: "#10b981",
                  fill: "#10b981",
                  points: [10, 14, 12, 18, 17, 24],
                },
                { label: "هزینه‌ها", color: "#f43f5e", points: [4, 7, 6, 9, 7, 10] },
              ]}
            />
          </Panel>
        </div>
        <Panel title="ترکیب مالی">
          <Donut
            segments={[
              { label: "درآمدها", value: 55, color: "#10b981" },
              { label: "هزینه‌ها", value: 20, color: "#f43f5e" },
              { label: "حق‌الوکاله", value: 25, color: "#2563eb" },
            ]}
          />
        </Panel>
      </div>
      <Panel title="تراکنش‌های اخیر">
        <Table
          head={["تاریخ", "شرح", "نوع", "پرونده / موکل"]}
          rows={[
            ["۱۴۰۳/۰۳/۲۰", "دریافت حق‌الوکاله", "درآمد", "پرونده مطالبه وجه"],
            ["۱۴۰۳/۰۳/۱۹", "هزینه دادرسی", "هزینه", "—"],
            ["۱۴۰۳/۰۳/۱۸", "دریافت قسط دوم", "درآمد", "آقای محمدی"],
            ["۱۴۰۳/۰۳/۱۷", "حق‌الزحمه کارشناس", "هزینه", "پرونده ملکی"],
          ]}
        />
      </Panel>
    </div>
  );
}

function ViewContracts() {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-xs font-bold text-slate-700">قراردادها</div>
        <div className="rounded-lg bg-amber-500 px-2.5 py-1 text-[10px] font-bold text-white">
          + قرارداد جدید
        </div>
      </div>
      <Table
        head={["عنوان قرارداد", "موکل", "نوع", "تاریخ", "مبلغ کل", "وضعیت"]}
        rows={[
          [
            "حق‌الوکاله پرونده کیفری",
            "شرکت پارس تجارت",
            "حق‌الوکاله",
            "۱۴۰۳/۰۳/۱۵",
            "۲۵۰,۰۰۰,۰۰۰",
            { chip: "فعال" },
          ],
          ["مشاوره حقوقی", "آقای محمدی", "مشاوره", "۱۴۰۳/۰۳/۱۰", "۸۰,۰۰۰,۰۰۰", { chip: "فعال" }],
          [
            "دعاوی ملکی",
            "خانم رضایی",
            "حق‌الوکاله",
            "۱۴۰۳/۰۳/۰۸",
            "۱۸۰,۰۰۰,۰۰۰",
            { chip: "در حال اجرا" },
          ],
          [
            "تنظیم سند رسمی",
            "آقای نادری",
            "تنظیم سند",
            "۱۴۰۳/۰۳/۰۲",
            "۳۰,۰۰۰,۰۰۰",
            { chip: "تکمیل شده" },
          ],
        ]}
      />
      <div className="grid grid-cols-2 gap-2">
        <Panel title="خلاصه قراردادها">
          <ul className="space-y-1.5 text-[10px] text-slate-600">
            {[
              ["تعداد کل قراردادها", "۵۸"],
              ["قراردادهای فعال", "۳۹"],
              ["در حال اجرا", "۱۲"],
              ["تکمیل شده", "۷"],
            ].map(([k, v]) => (
              <li key={k} className="flex justify-between rounded-lg bg-slate-50 px-2 py-1.5">
                <span>{k}</span>
                <span className="font-black text-slate-800">{v}</span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="خلاصه اقساط">
          <Donut
            segments={[
              { label: "پرداخت شده ۶۵٪", value: 65, color: "#10b981" },
              { label: "در حال پرداخت ۲۵٪", value: 25, color: "#f59e0b" },
              { label: "سررسید گذشته ۱۰٪", value: 10, color: "#2563eb" },
            ]}
          />
        </Panel>
      </div>
    </div>
  );
}

function ViewReports() {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        <Kpi label="پرونده‌های مختومه امسال" value="۴۲" tone="emerald" />
        <Kpi label="میانگین زمان رسیدگی" value="۷.۴ ماه" tone="amber" />
        <Kpi label="نرخ موفقیت پرونده‌ها" value="۸۶٪" />
      </div>
      <Panel title="عملکرد ماهانه دفتر (تعداد پرونده)">
        <Bars
          data={[
            { label: "فروردین", value: 9 },
            { label: "اردیبهشت", value: 14 },
            { label: "خرداد", value: 11 },
            { label: "تیر", value: 18 },
            { label: "مرداد", value: 15 },
            { label: "شهریور", value: 21 },
          ]}
        />
      </Panel>
      <div className="grid grid-cols-2 gap-2">
        <Panel title="گزارش‌های آماده">
          <ul className="space-y-1.5 text-[10px] text-slate-600">
            {["گزارش مالی سالانه", "گزارش جلسات دادگاه", "گزارش عملکرد موکلین", "ترازنامه دفتر"].map(
              (r) => (
                <li
                  key={r}
                  className="flex items-center justify-between rounded-lg bg-slate-50 px-2 py-1.5"
                >
                  <span>{r}</span>
                  <span className="rounded bg-slate-900 px-1.5 py-0.5 text-[9px] font-bold text-white">
                    PDF
                  </span>
                </li>
              ),
            )}
          </ul>
        </Panel>
        <Panel title="توزیع نوع پرونده‌ها">
          <Donut
            segments={[
              { label: "حقوقی", value: 44, color: "#2563eb" },
              { label: "کیفری", value: 26, color: "#f59e0b" },
              { label: "خانواده", value: 18, color: "#10b981" },
              { label: "ملکی", value: 12, color: "#f43f5e" },
            ]}
          />
        </Panel>
      </div>
    </div>
  );
}

const VIEWS: Record<ModuleView, () => ReactElement> = {
  dashboard: ViewDashboard,
  clients: ViewClients,
  finance: ViewFinance,
  contracts: ViewContracts,
  reports: ViewReports,
};

const TITLES: Record<ModuleView, string> = {
  dashboard: "پرونده‌ها و داشبورد",
  clients: "موکلین و جلسات",
  finance: "مدیریت مالی",
  contracts: "قراردادها و اسناد",
  reports: "گزارش‌ها و تحلیل",
};

export function AppPreview({ view = "dashboard" }: { view?: ModuleView }) {
  const View = VIEWS[view];
  const activeMenu =
    view === "dashboard" ? "dashboard" : view === "clients" ? "clients" : view;

  return (
    <div className="rounded-2xl border border-gold-500/30 bg-gradient-to-b from-ink-800 to-ink-950 p-2 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.9)]">
      {/* نوار عنوان */}
      <div className="flex items-center justify-between px-2 pt-1 pb-2">
        <div className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-rose-500/80" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
          <span className="h-2.5 w-2.5 rounded-full bg-emerald-500/80" />
        </div>
        <div className="text-[10px] font-bold text-gold-200/80">
          دفتر وکالت هوشمند — نسخه حرفه‌ای
        </div>
      </div>

      <div className="flex overflow-hidden rounded-xl bg-slate-100">
        {/* منوی کناری */}
        <aside className="hidden w-[104px] shrink-0 flex-col gap-0.5 bg-white p-2 sm:flex">
          <div className="mb-2 flex items-center gap-1.5 px-1">
            <span className="grid h-6 w-6 place-items-center rounded-md bg-gradient-to-br from-gold-400 to-gold-600 text-[10px] font-black text-ink-900">
              و
            </span>
            <span className="text-[10px] font-black text-slate-700">دفتر وکالت</span>
          </div>
          {MENU.map((m) => {
            const active = m.id === activeMenu;
            return (
              <div
                key={m.id}
                className={cn(
                  "flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-[10px] transition",
                  active
                    ? "bg-gradient-to-l from-gold-400 to-gold-500 font-bold text-ink-900 shadow"
                    : "text-slate-500",
                )}
              >
                <Icon name={m.icon} className="h-3.5 w-3.5" />
                {m.label}
              </div>
            );
          })}
        </aside>

        {/* محتوای اصلی */}
        <div className="min-w-0 flex-1 p-3">
          <div className="mb-3 flex items-center justify-between">
            <h4 className="text-xs font-black text-slate-800">{TITLES[view]}</h4>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-[9px] text-slate-400">
                <Icon name="search" className="h-3 w-3" />
                جستجو...
              </div>
              <div className="grid h-6 w-6 place-items-center rounded-full bg-slate-900 text-[9px] font-bold text-white">
                و
              </div>
            </div>
          </div>
          <View />
        </div>
      </div>
    </div>
  );
}

/** موبایل موکاپ کوچک برای کنار لپ‌تاپ */
export function PhonePreview() {
  return (
    <div className="w-[168px] rounded-[1.6rem] border-4 border-ink-700 bg-ink-900 p-1.5 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)]">
      <div className="overflow-hidden rounded-[1.2rem] bg-slate-100">
        <div className="flex items-center justify-between bg-white px-3 py-2 text-[9px] text-slate-500">
          <span>۹:۴۱</span>
          <span className="font-black text-slate-800">پرونده‌ها</span>
        </div>
        <div className="space-y-1.5 p-2">
          {[
            ["مطالبه وجه چک", "شعبه ۱۳ حقوقی", "در جریان"],
            ["خسارت قراردادی", "شعبه ۳ حقوقی", "در جریان"],
            ["الزام به تنظیم سند", "شعبه ۱ حقوقی", "مختومه"],
            ["طلاق توافقی", "شعبه خانواده", "در جریان"],
          ].map(([t, s, st]) => (
            <div key={t} className="rounded-lg bg-white p-2 shadow-sm">
              <div className="text-[9px] font-bold text-slate-800">{t}</div>
              <div className="mt-0.5 flex items-center justify-between">
                <span className="text-[8px] text-slate-400">{s}</span>
                <span
                  className={cn(
                    "rounded-full px-1.5 py-0.5 text-[7px] font-bold",
                    st === "مختومه"
                      ? "bg-emerald-100 text-emerald-700"
                      : "bg-amber-100 text-amber-700",
                  )}
                >
                  {st}
                </span>
              </div>
            </div>
          ))}
          <div className="rounded-lg bg-gradient-to-l from-gold-400 to-gold-600 py-1.5 text-center text-[9px] font-black text-ink-900">
            + پرونده جدید
          </div>
        </div>
      </div>
    </div>
  );
}
