import { useState, type FormEvent } from "react";
import { Icon } from "./Icons";
import { Reveal, SectionHeading } from "./Reveal";
import { CONTACT } from "../data/site";

const ROLES = ["وکیل پایه یک", "وکیل پایه دو / کارآموز", "مؤسسه حقوقی", "مشاور حقوقی", "سایر"];

export function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", role: ROLES[0], note: "" });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 6000);
    setForm({ name: "", phone: "", role: ROLES[0], note: "" });
  };

  const field =
    "w-full rounded-xl border border-white/10 bg-ink-950/70 px-4 py-3 text-sm text-white placeholder:text-slate-500 outline-none transition focus:border-gold-400/60 focus:ring-2 focus:ring-gold-500/20";

  return (
    <section id="contact" className="relative overflow-hidden py-20 md:py-28">
      <div className="absolute inset-x-0 top-0 h-px gold-line opacity-60" />
      <div className="absolute top-1/4 right-0 -z-10 h-80 w-80 rounded-full bg-gold-600/12 blur-[130px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="نسخه دمو و مشاوره رایگان"
          title={
            <>
              قبل از خرید، با تمامی امکانات نرم‌افزار <span className="gold-text">آشنا شوید</span>
            </>
          }
          subtitle="فرم زیر را تکمیل کنید یا مستقیماً تماس بگیرید؛ کارشناسان کارن سافت در کوتاه‌ترین زمان با شما هماهنگ می‌کنند."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-[1fr_0.85fr]">
          {/* فرم */}
          <Reveal>
            <form
              onSubmit={submit}
              className="card-dark rounded-3xl p-6 md:p-8"
              aria-label="فرم درخواست دمو"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-2 block text-xs font-bold text-slate-300">
                    نام و نام خانوادگی
                  </label>
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="مثال: علی محمدی"
                    className={field}
                  />
                </div>
                <div>
                  <label className="mb-2 block text-xs font-bold text-slate-300">شماره تماس</label>
                  <input
                    required
                    inputMode="tel"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    className={field}
                  />
                </div>
              </div>

              <div className="mt-4">
                <label className="mb-2 block text-xs font-bold text-slate-300">نوع فعالیت</label>
                <select
                  value={form.role}
                  onChange={(e) => setForm({ ...form, role: e.target.value })}
                  className={`${field} cursor-pointer`}
                >
                  {ROLES.map((r) => (
                    <option key={r} value={r} className="bg-ink-900">
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mt-4">
                <label className="mb-2 block text-xs font-bold text-slate-300">
                  توضیحات (اختیاری)
                </label>
                <textarea
                  rows={4}
                  value={form.note}
                  onChange={(e) => setForm({ ...form, note: e.target.value })}
                  placeholder="نیاز دفتر شما چیست؟ چند کاربر از نرم‌افزار استفاده می‌کنند؟"
                  className={`${field} resize-none`}
                />
              </div>

              <button
                type="submit"
                className="mt-6 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-gold-600 via-gold-400 to-gold-200 py-3.5 text-sm font-black text-ink-950 transition hover:shadow-lg hover:shadow-gold-500/30"
              >
                <Icon name="download" className="h-5 w-5" />
                ثبت درخواست نسخه دمو
              </button>

              {sent && (
                <div className="mt-4 flex items-center gap-2 rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-3 text-[13px] font-bold text-emerald-300">
                  <Icon name="check" className="h-4 w-4" strokeWidth={2.5} />
                  درخواست شما ثبت شد. همکاران ما به‌زودی با شما تماس می‌گیرند.
                </div>
              )}
              <p className="mt-3 text-center text-[11px] text-slate-500">
                اطلاعات شما نزد کارن سافت کاملاً محرمانه باقی می‌ماند.
              </p>
            </form>
          </Reveal>

          {/* اطلاعات تماس */}
          <Reveal delay={130} className="space-y-4">
            <a
              href={CONTACT.tel}
              className="group block rounded-3xl border border-gold-400/40 bg-gradient-to-br from-gold-600/20 via-ink-900 to-ink-950 p-7 transition hover:border-gold-300/70"
            >
              <div className="flex items-center gap-4">
                <span className="animate-pulse-ring grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-gold-400 to-gold-600 text-ink-950">
                  <Icon name="phone" className="h-7 w-7" strokeWidth={1.8} />
                </span>
                <div>
                  <div className="text-xs text-gold-200/80">
                    برای مشاوره و دریافت نسخه دمو تماس بگیرید
                  </div>
                  <div dir="ltr" className="mt-1 text-2xl font-black text-white md:text-3xl">
                    {CONTACT.phoneFa}
                  </div>
                </div>
              </div>
            </a>

            <div className="grid gap-3 sm:grid-cols-2">
              {[
                { icon: "mail", label: "ایمیل", value: CONTACT.email, dir: "ltr" },
                { icon: "clock", label: "ساعات پاسخگویی", value: CONTACT.hours },
                { icon: "location", label: "محدوده خدمات", value: CONTACT.address },
                { icon: "headset", label: "پشتیبانی", value: "تلفنی و از راه دور (AnyDesk)" },
              ].map((c) => (
                <div key={c.label} className="card-dark rounded-2xl p-4">
                  <div className="mb-2 flex items-center gap-2 text-gold-300">
                    <Icon name={c.icon as "mail"} className="h-4 w-4" />
                    <span className="text-[11px] font-bold">{c.label}</span>
                  </div>
                  <div
                    dir={c.dir as "ltr" | undefined}
                    className="text-[12px] leading-6 text-slate-300/80"
                  >
                    {c.value}
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <div className="mb-3 flex items-center gap-2 text-sm font-black text-white">
                <Icon name="shield" className="h-4.5 w-4.5 text-gold-300" />
                تضمین کارن سافت
              </div>
              <ul className="space-y-2">
                {[
                  "نصب و راه‌اندازی رایگان توسط تیم فنی",
                  "انتقال اطلاعات از نرم‌افزار قبلی",
                  "آموزش کامل کاربران دفتر",
                  "به‌روزرسانی رایگان در دوره پشتیبانی",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-2 text-[12px] text-slate-300/80">
                    <Icon
                      name="check"
                      className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400"
                      strokeWidth={2.6}
                    />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
