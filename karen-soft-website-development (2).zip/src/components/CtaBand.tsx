import { Icon } from "./Icons";
import { Reveal } from "./Reveal";
import { CONTACT } from "../data/site";
import appIcon from "../assets/app-icon.jpg";

export function CtaBand() {
  const go = () =>
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <section className="relative overflow-hidden py-16 md:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl border border-gold-500/30 bg-gradient-to-l from-ink-900 via-ink-850 to-ink-900 p-8 md:p-12">
            <div className="absolute -top-24 -left-24 h-64 w-64 rounded-full bg-gold-500/12 blur-[90px]" />
            <div className="absolute -right-20 -bottom-24 h-64 w-64 rounded-full bg-brand-500/12 blur-[90px]" />
            <div className="grid items-center gap-8 md:grid-cols-[auto_1fr_auto]">
              <img
                src={appIcon}
                alt="دفتر وکالت هوشمند"
                className="animate-float mx-auto h-28 w-28 rounded-2xl border border-gold-500/30 object-cover shadow-2xl md:h-32 md:w-32"
              />
              <div className="text-center md:text-right">
                <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-gold-400/30 bg-gold-500/10 px-3 py-1 text-[11px] font-bold text-gold-200">
                  <Icon name="sparkles" className="h-3.5 w-3.5" />
                  نسخه دمو و مشاوره رایگان
                </div>
                <h3 className="text-2xl leading-relaxed font-black text-white md:text-3xl">
                  همین امروز دفتر وکالت خود را <span className="gold-text">هوشمند</span> کنید
                </h3>
                <p className="mt-3 leading-8 text-slate-300/80">
                  قبل از خرید، نرم‌افزار را به‌صورت کامل تست کنید و با تمامی امکانات آن آشنا شوید.
                </p>
              </div>
              <div className="flex flex-col gap-3">
                <a
                  href={CONTACT.tel}
                  dir="ltr"
                  className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-gold-600 via-gold-400 to-gold-200 px-7 py-3.5 text-base font-black text-ink-950 shadow-lg shadow-gold-600/25 transition hover:shadow-xl hover:shadow-gold-500/40"
                >
                  <Icon name="phone" className="h-5 w-5" />
                  {CONTACT.phoneFa}
                </a>
                <button
                  onClick={go}
                  className="cursor-pointer rounded-xl border border-gold-400/35 px-7 py-3 text-sm font-black text-gold-200 transition hover:bg-gold-500/10"
                >
                  ثبت درخواست آنلاین
                </button>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
