import { useState } from "react";
import { Icon } from "./Icons";
import { Reveal, SectionHeading } from "./Reveal";
import { FAQ } from "../data/site";
import { cn } from "../utils/cn";

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section
      id="faq"
      className="relative overflow-hidden border-t border-white/5 bg-ink-950 py-20 md:py-28"
    >
      <div className="absolute bottom-0 left-1/4 -z-10 h-72 w-72 rounded-full bg-brand-600/12 blur-[130px]" />
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="سوالات متداول"
          title={
            <>
              پاسخ سوال‌های <span className="gold-text">پرتکرار شما</span>
            </>
          }
        />

        <div className="mt-12 space-y-3">
          {FAQ.map((item, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={item.q} delay={i * 60}>
                <div
                  className={cn(
                    "overflow-hidden rounded-2xl border transition duration-300",
                    isOpen
                      ? "border-gold-400/45 bg-gradient-to-l from-ink-850 to-ink-900"
                      : "border-white/10 bg-white/[0.02] hover:border-gold-400/25",
                  )}
                >
                  <button
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full cursor-pointer items-center justify-between gap-4 px-5 py-4 text-right"
                  >
                    <span
                      className={cn(
                        "text-sm font-black transition md:text-[15px]",
                        isOpen ? "text-gold-200" : "text-white",
                      )}
                    >
                      {item.q}
                    </span>
                    <span
                      className={cn(
                        "grid h-8 w-8 shrink-0 place-items-center rounded-lg border transition duration-300",
                        isOpen
                          ? "rotate-180 border-gold-400/50 bg-gold-500/15 text-gold-300"
                          : "border-white/10 text-slate-400",
                      )}
                    >
                      <Icon name="chevronDown" className="h-4 w-4" />
                    </span>
                  </button>
                  <div
                    className={cn(
                      "grid transition-all duration-400",
                      isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                    )}
                  >
                    <div className="overflow-hidden">
                      <p className="px-5 pb-5 text-[13px] leading-8 text-slate-300/75">{item.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
