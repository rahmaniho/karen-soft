import { Icon } from "./Icons";
import { Reveal, SectionHeading } from "./Reveal";
import { EXTRAS, FEATURES } from "../data/site";

export function Features() {
  return (
    <section id="features" className="relative overflow-hidden py-20 md:py-28">
      <div className="absolute inset-x-0 top-0 h-px gold-line opacity-60" />
      <div className="absolute top-1/3 -right-24 -z-10 h-72 w-72 rounded-full bg-gold-600/10 blur-[120px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="ویژگی‌های ویژه"
          title={
            <>
              طراحی‌شده برای <span className="gold-text">وکلا و دفترهای حرفه‌ای</span>
            </>
          }
          subtitle="نرم‌افزاری جامع و پکپارچه برای مدیریت حرفه‌ای دفتر وکالت و مؤسسات حقوقی؛ ساده، سریع و کاملاً امن."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={(i % 5) * 70}>
              <article className="group card-dark relative h-full overflow-hidden rounded-2xl p-5 transition duration-500 hover:-translate-y-1.5 hover:border-gold-400/50">
                <div className="absolute -top-16 -left-16 h-32 w-32 rounded-full bg-gold-500/0 blur-2xl transition-all duration-500 group-hover:bg-gold-500/20" />
                <div className="relative mb-4 grid h-12 w-12 place-items-center rounded-xl border border-gold-400/35 bg-gradient-to-br from-gold-500/20 to-transparent text-gold-300 transition group-hover:scale-110">
                  <Icon name={f.icon} className="h-6 w-6" strokeWidth={1.5} />
                </div>
                <h3 className="mb-2 text-base font-black text-white">{f.title}</h3>
                <p className="text-[13px] leading-7 text-slate-300/70">{f.desc}</p>
              </article>
            </Reveal>
          ))}
        </div>

        {/* نوار امکانات جانبی */}
        <Reveal delay={120} className="mt-8">
          <div className="grid gap-3 rounded-2xl border border-gold-500/20 bg-gradient-to-l from-ink-900 via-ink-850 to-ink-900 p-5 sm:grid-cols-2 lg:grid-cols-5">
            {EXTRAS.map((e) => (
              <div key={e.title} className="flex items-start gap-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-gold-500/12 text-gold-300">
                  <Icon name={e.icon} className="h-5 w-5" />
                </span>
                <div>
                  <div className="text-sm font-black text-white">{e.title}</div>
                  <div className="mt-0.5 text-[11px] leading-5 text-slate-400">{e.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
