import { Icon } from "./Icons";
import { KarenLogo } from "./Logo";
import { CONTACT, NAV_LINKS } from "../data/site";

export function Footer() {
  const go = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <footer className="relative overflow-hidden border-t border-gold-500/15 bg-ink-950 pt-14 pb-8">
      <div className="grid-bg absolute inset-0 -z-10 opacity-25" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <KarenLogo />
            <p className="mt-5 max-w-md text-[13px] leading-8 text-slate-400">
              شرکت نرم‌افزاری کارن سافت، توسعه‌دهنده نرم‌افزار{" "}
              <strong className="text-gold-300">دفتر وکالت هوشمند</strong> و سامانه‌های تخصصی
              سازمانی. اطلاعات شما، سرمایه اعتماد ماست.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href={CONTACT.tel}
                dir="ltr"
                className="flex items-center gap-2 rounded-xl border border-gold-400/30 bg-gold-500/10 px-4 py-2 text-sm font-black text-gold-200 transition hover:bg-gold-500/20"
              >
                <Icon name="phone" className="h-4 w-4" />
                {CONTACT.phoneFa}
              </a>
              <a
                href={`mailto:${CONTACT.email}`}
                dir="ltr"
                className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold text-slate-300 transition hover:bg-white/10"
              >
                <Icon name="mail" className="h-4 w-4" />
                {CONTACT.email}
              </a>
            </div>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-black text-white">دسترسی سریع</h4>
            <ul className="space-y-2.5">
              {NAV_LINKS.map((l) => (
                <li key={l.id}>
                  <button
                    onClick={() => go(l.id)}
                    className="cursor-pointer text-[13px] text-slate-400 transition hover:text-gold-300"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-black text-white">امکانات محصول</h4>
            <ul className="space-y-2.5 text-[13px] text-slate-400">
              {[
                "مدیریت پرونده‌ها",
                "موکلین و جلسات",
                "قراردادها و اقساط",
                "مدیریت مالی و حق‌الوکاله",
                "گزارش‌های حرفه‌ای",
                "پشتیبان‌گیری خودکار",
              ].map((t) => (
                <li key={t} className="flex items-center gap-2">
                  <span className="h-1 w-1 rounded-full bg-gold-400" />
                  {t}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/8 pt-6 text-center text-[12px] text-slate-500 md:flex-row md:text-right">
          <span>
            © {new Date().getFullYear().toLocaleString("fa-IR", { useGrouping: false })} تمامی حقوق
            برای شرکت کارن سافت محفوظ است.
          </span>
          <span className="flex items-center gap-2">
            <Icon name="lock" className="h-3.5 w-3.5 text-gold-500" />
            طراحی و توسعه: تیم فنی کارن سافت
          </span>
        </div>
      </div>
    </footer>
  );
}
