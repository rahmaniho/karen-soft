import { Icon } from "./Icons";
import { AppPreview, PhonePreview } from "./AppPreview";
import { Reveal } from "./Reveal";
import { CONTACT, HERO_BADGES, STATS } from "../data/site";
import appIcon from "../assets/app-icon.jpg";

export function Hero() {
  const go = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <section id="home" className="relative overflow-hidden pt-28 pb-16 md:pt-36 md:pb-24">
      {/* پس‌زمینه */}
      <div className="absolute inset-0 -z-20 bg-[radial-gradient(120%_90%_at_80%_0%,#132038_0%,#0a0e1a_45%,#05070f_100%)]" />
      <div className="grid-bg absolute inset-0 -z-10 opacity-40" />
      <div className="absolute -top-24 right-1/4 -z-10 h-72 w-72 rounded-full bg-gold-500/12 blur-[110px]" />
      <div className="absolute top-40 -left-20 -z-10 h-80 w-80 rounded-full bg-brand-600/20 blur-[120px]" />
      {/* ترازوی عدالت تزئینی */}
      <svg
        viewBox="0 0 24 24"
        className="pointer-events-none absolute -top-6 right-[-4rem] -z-10 h-[26rem] w-[26rem] text-gold-500/[0.07] md:right-[2rem]"
        fill="none"
        stroke="currentColor"
        strokeWidth={0.5}
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <path d="M12 3.2v17M7.5 20.5h9M3.5 8.2h17M12 3.2l-8.5 5M12 3.2l8.5 5" />
        <path d="M3.5 8.2L.9 14a2.9 2.9 0 005.2 0L3.5 8.2zM20.5 8.2L17.9 14a2.9 2.9 0 005.2 0l-2.6-5.8z" />
        <circle cx="12" cy="2.6" r="0.9" />
      </svg>

      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[1.05fr_1fr]">
        {/* متن */}
        <div>
          <Reveal>
            <div className="inline-flex items-center gap-2 rounded-full border border-gold-400/30 bg-gold-500/10 px-4 py-1.5 text-xs font-bold text-gold-200">
              <Icon name="sparkles" className="h-4 w-4" />
              محصول شرکت نرم‌افزاری کارن سافت
            </div>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="mt-6 text-4xl leading-[1.25] font-black text-white sm:text-5xl lg:text-[3.4rem]">
              همین امروز مدیریت دفتر خود را
              <br />
              <span className="gold-text animate-shine">هوشمند</span> کنید
            </h1>
          </Reveal>

          <Reveal delay={140}>
            <p className="mt-5 max-w-xl text-base leading-9 text-slate-300/85 md:text-lg">
              <strong className="font-black text-white">دفتر وکالت هوشمند</strong>، نرم‌افزار جامع و
              یکپارچه مدیریت دفاتر وکالت و مؤسسات حقوقی؛ از پرونده‌ها، موکلین و جلسات دادگاه تا
              قراردادها، حق‌الوکاله و گزارش‌های مالی — همه در یک برنامه.
            </p>
          </Reveal>

          <Reveal delay={200}>
            <div className="mt-6 flex flex-wrap items-center gap-2">
              {HERO_BADGES.map((b) => (
                <span
                  key={b}
                  className="rounded-lg border border-gold-500/25 bg-ink-800/70 px-4 py-1.5 text-sm font-bold text-gold-200"
                >
                  {b}
                </span>
              ))}
            </div>
          </Reveal>

          <Reveal delay={260}>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button
                onClick={() => go("contact")}
                className="group flex cursor-pointer items-center gap-2 rounded-xl bg-gradient-to-l from-gold-600 via-gold-400 to-gold-200 px-6 py-3.5 text-sm font-black text-ink-950 shadow-lg shadow-gold-600/25 transition hover:shadow-xl hover:shadow-gold-500/40"
              >
                <Icon name="download" className="h-5 w-5" />
                دریافت نسخه دمو رایگان
                <Icon
                  name="arrowLeft"
                  className="h-4 w-4 transition-transform group-hover:-translate-x-1"
                />
              </button>
              <a
                href={CONTACT.tel}
                dir="ltr"
                className="animate-pulse-ring flex items-center gap-2 rounded-xl border border-gold-400/35 bg-white/5 px-6 py-3.5 text-sm font-black text-white backdrop-blur transition hover:bg-white/10"
              >
                <Icon name="phone" className="h-5 w-5 text-gold-300" />
                {CONTACT.phoneFa}
              </a>
            </div>
          </Reveal>

          <Reveal delay={320}>
            <div className="mt-9 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-slate-300/80">
              <span className="font-bold text-slate-200">مناسب برای:</span>
              {[
                { icon: "briefcase", label: "وکلا" },
                { icon: "scale", label: "مؤسسات حقوقی" },
                { icon: "users", label: "مشاوران حقوقی" },
              ].map((i) => (
                <span key={i.label} className="flex items-center gap-2">
                  <Icon name={i.icon as "users"} className="h-4 w-4 text-gold-400" />
                  {i.label}
                </span>
              ))}
            </div>
          </Reveal>
        </div>

        {/* موکاپ */}
        <Reveal delay={200} className="relative">
          <div className="relative">
            <div className="absolute -inset-6 -z-10 rounded-[2rem] bg-gradient-to-tr from-gold-500/12 via-transparent to-brand-500/12 blur-2xl" />
            <AppPreview view="dashboard" />
            <div className="animate-float absolute -bottom-10 -left-6 hidden md:block">
              <PhonePreview />
            </div>
            <div className="absolute -top-8 -left-4 hidden rounded-2xl border border-gold-500/30 bg-ink-900/90 p-1.5 shadow-2xl backdrop-blur sm:block">
              <img
                src={appIcon}
                alt="نرم‌افزار دفتر وکالت هوشمند"
                className="h-20 w-20 rounded-xl object-cover"
              />
            </div>
          </div>
        </Reveal>
      </div>

      {/* آمار */}
      <div className="mx-auto mt-16 max-w-7xl px-4 sm:px-6 md:mt-24">
        <div className="grid grid-cols-2 gap-3 rounded-2xl border border-gold-500/15 bg-ink-900/60 p-4 backdrop-blur sm:gap-4 md:grid-cols-4 md:p-6">
          {STATS.map((s, i) => (
            <Reveal
              key={s.label}
              delay={i * 90}
              className="rounded-xl border border-white/5 bg-white/[0.03] p-4 text-center"
            >
              <div className="text-2xl font-black md:text-3xl">
                <span className="gold-text">{s.value}</span>
                <span className="text-lg text-gold-400/80">{s.suffix}</span>
              </div>
              <div className="mt-1 text-xs text-slate-300/70 md:text-sm">{s.label}</div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
