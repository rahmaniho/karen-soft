import type { SVGProps } from "react";

export type IconName =
  | "shield"
  | "cloud"
  | "database"
  | "chart"
  | "search"
  | "monitor"
  | "gauge"
  | "wifiOff"
  | "users"
  | "globe"
  | "lock"
  | "printer"
  | "file"
  | "settings"
  | "headset"
  | "calendar"
  | "bell"
  | "folder"
  | "wallet"
  | "pie"
  | "handshake"
  | "receipt"
  | "scale"
  | "phone"
  | "mail"
  | "check"
  | "chevronDown"
  | "menu"
  | "close"
  | "sparkles"
  | "briefcase"
  | "clipboard"
  | "download"
  | "bolt"
  | "arrowLeft"
  | "star"
  | "location"
  | "clock"
  | "layers"
  | "home";

const paths: Record<IconName, React.ReactNode> = {
  shield: <path d="M12 3l7 3v6c0 4.2-2.9 7.8-7 9-4.1-1.2-7-4.8-7-9V6l7-3z" />,
  cloud: (
    <>
      <path d="M7 18a4 4 0 010-8 5.5 5.5 0 0110.5-1.5A3.75 3.75 0 0117.5 18H7z" />
      <path d="M12 15V9m0 0l-2.2 2.2M12 9l2.2 2.2" />
    </>
  ),
  database: (
    <>
      <ellipse cx="12" cy="6" rx="7" ry="3" />
      <path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6" />
      <path d="M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6" />
    </>
  ),
  chart: (
    <>
      <path d="M4 20h16" />
      <path d="M7 20v-6M12 20V7M17 20v-9" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="6" />
      <path d="M20 20l-3.5-3.5" />
    </>
  ),
  monitor: (
    <>
      <rect x="3" y="4" width="18" height="12" rx="2" />
      <path d="M8 20h8M12 16v4" />
    </>
  ),
  gauge: (
    <>
      <path d="M4 18a8 8 0 1116 0" />
      <path d="M12 18l4-5" />
    </>
  ),
  wifiOff: (
    <>
      <path d="M3 3l18 18" />
      <path d="M8.5 15.5a5 5 0 017 0" />
      <path d="M5 12a10 10 0 014.5-2.6M19 12a10 10 0 00-6.4-2.9" />
      <path d="M12 19h.01" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3" />
      <path d="M3 19a6 6 0 0112 0" />
      <path d="M16 6.5a3 3 0 010 5.8M17 19a6 6 0 00-1.2-3.6" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="8" />
      <path d="M4 12h16M12 4c2.2 2.3 3.3 5.1 3.3 8s-1.1 5.7-3.3 8c-2.2-2.3-3.3-5.1-3.3-8S9.8 6.3 12 4z" />
    </>
  ),
  lock: (
    <>
      <rect x="5" y="10" width="14" height="10" rx="2" />
      <path d="M8 10V8a4 4 0 018 0v2" />
      <path d="M12 14v2" />
    </>
  ),
  printer: (
    <>
      <path d="M7 9V4h10v5" />
      <rect x="4" y="9" width="16" height="7" rx="2" />
      <path d="M7 14h10v6H7z" />
    </>
  ),
  file: (
    <>
      <path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8l-5-5z" />
      <path d="M14 3v5h5" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19 12a7 7 0 00-.1-1.2l2-1.5-2-3.4-2.3 1a7 7 0 00-2-1.2L14.2 3H9.8l-.4 2.7a7 7 0 00-2 1.2l-2.3-1-2 3.4 2 1.5a7 7 0 000 2.4l-2 1.5 2 3.4 2.3-1a7 7 0 002 1.2l.4 2.7h4.4l.4-2.7a7 7 0 002-1.2l2.3 1 2-3.4-2-1.5c.06-.4.1-.8.1-1.2z" />
    </>
  ),
  headset: (
    <>
      <path d="M4 14v-2a8 8 0 0116 0v2" />
      <rect x="2.5" y="13" width="4" height="6" rx="1.5" />
      <rect x="17.5" y="13" width="4" height="6" rx="1.5" />
      <path d="M19.5 19v.5a2.5 2.5 0 01-2.5 2.5h-2" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M3 10h18M8 3v4M16 3v4" />
    </>
  ),
  bell: (
    <>
      <path d="M18 15V10a6 6 0 10-12 0v5l-2 3h16l-2-3z" />
      <path d="M10 21h4" />
    </>
  ),
  folder: <path d="M3 7a2 2 0 012-2h4l2 2.5h8a2 2 0 012 2V17a2 2 0 01-2 2H5a2 2 0 01-2-2V7z" />,
  wallet: (
    <>
      <path d="M3 8a2 2 0 012-2h12a2 2 0 012 2v1" />
      <rect x="3" y="8" width="18" height="11" rx="2" />
      <path d="M16 13.5h2" />
    </>
  ),
  pie: (
    <>
      <path d="M12 3a9 9 0 109 9h-9V3z" />
      <path d="M15 3.6A9 9 0 0120.4 9H15V3.6z" />
    </>
  ),
  handshake: (
    <>
      <path d="M8 12l3-3 3 2 4-4 3 3-6 7-3-2-2 2-4-4 2-1z" />
      <path d="M2 10l4-4" />
    </>
  ),
  receipt: (
    <>
      <path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3z" />
      <path d="M9 8h6M9 12h6" />
    </>
  ),
  scale: (
    <>
      <path d="M12 4v16M7 20h10M4 9h16" />
      <path d="M4 9l-2.5 5a2.8 2.8 0 005 0L4 9zM20 9l-2.5 5a2.8 2.8 0 005 0L20 9z" />
    </>
  ),
  phone: (
    <path d="M6 3h3l2 5-2.5 1.5a12 12 0 005 5L15 12l5 2v3a2 2 0 01-2.2 2A16.5 16.5 0 014 6.2 2 2 0 016 3z" />
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="M3.5 7l8.5 6 8.5-6" />
    </>
  ),
  check: <path d="M5 12.5l4.5 4.5L19 7" />,
  chevronDown: <path d="M6 9l6 6 6-6" />,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  sparkles: (
    <>
      <path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3z" />
      <path d="M18 15l.9 2.3 2.3.9-2.3.9-.9 2.3-.9-2.3-2.3-.9 2.3-.9L18 15z" />
    </>
  ),
  briefcase: (
    <>
      <rect x="3" y="7" width="18" height="13" rx="2" />
      <path d="M9 7V5.5A1.5 1.5 0 0110.5 4h3A1.5 1.5 0 0115 5.5V7M3 12h18" />
    </>
  ),
  clipboard: (
    <>
      <rect x="5" y="4" width="14" height="17" rx="2" />
      <path d="M9 4.5A1.5 1.5 0 0110.5 3h3A1.5 1.5 0 0115 4.5V6H9V4.5z" />
      <path d="M9 11h6M9 15h4" />
    </>
  ),
  download: (
    <>
      <path d="M12 4v10m0 0l-3.5-3.5M12 14l3.5-3.5" />
      <path d="M5 18h14" />
    </>
  ),
  bolt: <path d="M13 3L5 13h6l-1 8 8-10h-6l1-8z" />,
  arrowLeft: <path d="M19 12H5m0 0l6-6m-6 6l6 6" />,
  star: <path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.7l5.9-.9L12 3.5z" />,
  location: (
    <>
      <path d="M12 21s7-6.1 7-11a7 7 0 10-14 0c0 4.9 7 11 7 11z" />
      <circle cx="12" cy="10" r="2.5" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </>
  ),
  layers: (
    <>
      <path d="M12 3l9 5-9 5-9-5 9-5z" />
      <path d="M3 13l9 5 9-5" />
    </>
  ),
  home: (
    <>
      <path d="M4 11l8-6.5 8 6.5" />
      <path d="M6.5 10.5V20h11v-9.5" />
    </>
  ),
};

interface IconProps extends SVGProps<SVGSVGElement> {
  name: IconName;
}

export function Icon({ name, ...props }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...props}
    >
      {paths[name]}
    </svg>
  );
}
