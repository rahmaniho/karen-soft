interface MarkProps {
  className?: string;
}

/** نشان اختصاصی کارن سافت (KS) */
export function KarenMark({ className = "h-10 w-10" }: MarkProps) {
  return (
    <svg viewBox="0 0 100 100" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="ksGrad" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#0d2f7a" />
          <stop offset="45%" stopColor="#1b7ce0" />
          <stop offset="100%" stopColor="#57d0ff" />
        </linearGradient>
      </defs>
      <g fill="url(#ksGrad)">
        {/* حرف K */}
        <path d="M14 14h16v72H14z" />
        <path d="M30 50L58 14h20L46 50z" />
        <path d="M30 50h16l28 36H54z" />
        {/* پیکسل‌های دیجیتال */}
        <rect x="4" y="72" width="7" height="7" opacity="0.85" />
        <rect x="9" y="82" width="6" height="6" opacity="0.6" />
        <rect x="0" y="86" width="5" height="5" opacity="0.4" />
      </g>
      {/* حرف S/G */}
      <path
        d="M88 30a22 22 0 10 4 24H70"
        fill="none"
        stroke="url(#ksGrad)"
        strokeWidth="15"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function KarenLogo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative">
        <div className="absolute inset-0 -z-10 rounded-2xl bg-brand-500/25 blur-lg" />
        <KarenMark className="h-10 w-10 drop-shadow-[0_2px_8px_rgba(27,124,224,0.5)]" />
      </div>
      <div className="leading-tight">
        <div className="text-lg font-black text-white">کارن سافت</div>
        {!compact && (
          <div className="text-[10px] font-bold tracking-[0.3em] text-brand-300 uppercase">
            Karensoft
          </div>
        )}
      </div>
    </div>
  );
}
