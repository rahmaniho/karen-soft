import { useState } from "react";
import { Icon } from "./Icons";
import { AppPreview } from "./AppPreview";
import { Reveal, SectionHeading } from "./Reveal";
import { MODULES, type ModuleView } from "../data/site";
import { cn } from "../utils/cn";

export function Modules() {
  const [active, setActive] = useState<ModuleView>("dashboard");
  const current = MODULES.find((m) => m.id === active)!;

  return (
    <section
      id="modules"
      className="relative overflow-hidden border-y border-white/5 bg-gradient-to-b from-ink-950 via-ink-900 to-ink-950 py-20 md:py-28"
    >
      <div className="absolute top-1/4 -left-32 -z-10 h-80 w-80 rounded-full bg-brand-600/15 blur-[130px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="امکانات نرم‌افزار"
          title={
            <>
              همه بخش‌های دفتر شما در <span className="gold-text">یک سیستم یکپارچه</span>
            </>
          }
          subtitle="روی هر بخش کلیک کنید تا محیط واقعی نرم‌افزار را ببینید."
        />

        {/* تب‌ها */}
        <Reveal className="mt-10">
          <div className="flex flex-wrap justify-center gap-2">
            {MODULES.map((m) => (
              <button
                key={m.id}
                onClick={() => setActive(m.id)}
                className={cn(
                  "flex cursor-pointer items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-bold transition duration-300",
                  active === m.id
                    ? "border-gold-400/60 bg-gradient-to-l from-gold-600/25 to-gold-400/10 text-gold-100 shadow-lg shadow-gold-900/40"
                    : "border-white/10 bg-white/[0.03] text-slate-300 hover:border-gold-400/30 hover:text-white",
                )}
              >
                <Icon name={m.icon} className="h-4.5 w-4.5" />
                {m.tab}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="mt-10 grid items-center gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div key={current.id} className="reveal is-visible">
            <h3 className="text-2xl leading-relaxed font-black text-white md:text-3xl">
              {current.title}
            </h3>
            <p className="mt-4 leading-8 text-slate-300/80">{current.desc}</p>

            <div className="mt-7 grid gap-3 sm:grid-cols-2">
              {current.points.map((p) => (
                <div
                  key={p.title}
                  className="card-dark group rounded-xl p-4 transition hover:border-gold-400/40"
                >
                  <div className="mb-2 flex items-center gap-2.5">
                    <span className="grid h-9 w-9 place-items-center rounded-lg border border-gold-400/30 bg-gold-500/10 text-gold-300">
                      <Icon name={p.icon} className="h-4.5 w-4.5" />
                    </span>
                    <span className="text-sm font-black text-white">{p.title}</span>
                  </div>
                  <p className="text-[12px] leading-6 text-slate-400">{p.desc}</p>
                </div>
              ))}
            </div>

            <a
              href="#contact"
              className="mt-7 inline-flex items-center gap-2 text-sm font-black text-gold-300 transition hover:text-gold-200"
            >
              مشاهده این بخش در نسخه دمو
              <Icon name="arrowLeft" className="h-4 w-4" />
            </a>
          </div>

          <div className="relative">
            <div className="absolute -inset-5 -z-10 rounded-[2rem] bg-gradient-to-br from-gold-500/10 via-transparent to-brand-500/10 blur-2xl" />
            <AppPreview view={active} />
          </div>
        </div>
      </div>
    </section>
  );
}
