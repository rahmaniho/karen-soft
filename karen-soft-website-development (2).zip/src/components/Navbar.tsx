import { useEffect, useState } from "react";
import { Icon } from "./Icons";
import { KarenLogo } from "./Logo";
import { CONTACT, NAV_LINKS } from "../data/site";
import { cn } from "../utils/cn";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const sections = NAV_LINKS.map((l) => document.getElementById(l.id)).filter(
        Boolean,
      ) as HTMLElement[];
      const current = sections.find((s) => {
        const rect = s.getBoundingClientRect();
        return rect.top <= 140 && rect.bottom >= 140;
      });
      if (current) setActive(current.id);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled
          ? "border-b border-gold-500/15 bg-ink-950/85 py-2 backdrop-blur-xl"
          : "border-b border-transparent py-4",
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <button onClick={() => go("home")} className="shrink-0 cursor-pointer">
          <KarenLogo />
        </button>

        <nav className="hidden items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-1.5 backdrop-blur lg:flex">
          {NAV_LINKS.map((link) => (
            <button
              key={link.id}
              onClick={() => go(link.id)}
              className={cn(
                "cursor-pointer rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition",
                active === link.id
                  ? "bg-gradient-to-l from-gold-500 to-gold-300 text-ink-950 shadow-lg shadow-gold-500/20"
                  : "text-slate-300 hover:bg-white/10 hover:text-white",
              )}
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={CONTACT.tel}
            className="hidden items-center gap-2 rounded-full border border-gold-400/40 bg-gold-500/10 px-4 py-2 text-sm font-black text-gold-200 transition hover:bg-gold-500/20 sm:flex"
            dir="ltr"
          >
            <Icon name="phone" className="h-4 w-4" />
            {CONTACT.phoneFa}
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            aria-label="منو"
            className="grid h-10 w-10 cursor-pointer place-items-center rounded-xl border border-white/10 bg-white/5 text-white lg:hidden"
          >
            <Icon name={open ? "close" : "menu"} className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* منوی موبایل */}
      <div
        className={cn(
          "overflow-hidden transition-all duration-400 lg:hidden",
          open ? "max-h-[520px] opacity-100" : "max-h-0 opacity-0",
        )}
      >
        <div className="mx-4 mt-3 rounded-2xl border border-gold-500/20 bg-ink-900/95 p-3 backdrop-blur-xl">
          <div className="grid gap-1">
            {NAV_LINKS.map((link) => (
              <button
                key={link.id}
                onClick={() => go(link.id)}
                className={cn(
                  "cursor-pointer rounded-xl px-4 py-2.5 text-right text-sm font-semibold transition",
                  active === link.id
                    ? "bg-gold-500/15 text-gold-200"
                    : "text-slate-300 hover:bg-white/5",
                )}
              >
                {link.label}
              </button>
            ))}
          </div>
          <a
            href={CONTACT.tel}
            dir="ltr"
            className="mt-3 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-gold-600 to-gold-300 py-3 text-sm font-black text-ink-950"
          >
            <Icon name="phone" className="h-4 w-4" />
            {CONTACT.phoneFa}
          </a>
        </div>
      </div>
    </header>
  );
}
