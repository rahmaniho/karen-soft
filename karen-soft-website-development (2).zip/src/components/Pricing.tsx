import { Icon } from "./Icons";
import { Reveal, SectionHeading } from "./Reveal";
import { CONTACT, PLANS } from "../data/site";
import { cn } from "../utils/cn";

export function Pricing() {
  const go = () =>
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <section id="pricing" className="relative overflow-hidden py-20 md:py-28">
      <div className="absolute top-10 left-1/3 -z-10 h-72 w-72 rounded-full bg-gold-600/10 blur-[130px]" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="تعرفه‌ها"
          title={
            <>
              نسخه‌ای متناسب با <span className="gold-text">اندازه دفتر شما</span>
            </>
          }
          subtitle="لایسنس دائمی، بدون هزینه اشتراک ماهانه. نصب، انتقال اطلاعات و آموزش اولیه در همه نسخه‌ها رایگان است."
        />

        <div className="mt-14 grid items-stretch gap-5 lg:grid-cols-3">
          {PLANS.map((plan, i) => (
            <Reveal key={plan.name} delay={i * 110} className="h-full">
              <div
                className={cn(
                  "relative flex h-full flex-col rounded-3xl p-7 transition duration-500 hover:-translate-y-2",
                  plan.featured
                    ? "border-2 border-gold-400/60 bg-gradient-to-b from-ink-800 via-ink-850 to-ink-950 shadow-[0_25px_70px_-25px_rgba(217,173,69,0.45)]"
                    : "card-dark",
                )}
              >
                {plan.featured && (
                  <span className="absolute -top-3.5 right-1/2 translate-x-1/2 rounded-full bg-gradient-to-l from-gold-600 to-gold-300 px-4 py-1 text-[11px] font-black text-ink-950 shadow-lg">
                    پیشنهاد کارن سافت
                  </span>
                )}
                <div className="mb-1 text-lg font-black text-white">{plan.name}</div>
                <div className="text-xs text-gold-300/80">{plan.tagline}</div>

                <div className="my-6 border-y border-white/10 py-5">
                  <div className="flex items-end gap-2">
                    <span
                      className={cn(
                        "text-3xl font-black",
                        plan.featured ? "gold-text" : "text-white",
                      )}
                    >
                      {plan.price}
                    </span>
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400">{plan.unit}</div>
                </div>

                <ul className="mb-7 flex-1 space-y-2.5">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-[13px] text-slate-300/85">
                      <span className="mt-0.5 grid h-4.5 w-4.5 shrink-0 place-items-center rounded-full bg-gold-500/15 text-gold-300">
                        <Icon name="check" className="h-3 w-3" strokeWidth={2.6} />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={go}
                  className={cn(
                    "cursor-pointer rounded-xl py-3 text-sm font-black transition",
                    plan.featured
                      ? "bg-gradient-to-l from-gold-600 via-gold-400 to-gold-200 text-ink-950 hover:shadow-lg hover:shadow-gold-500/30"
                      : "border border-gold-400/35 text-gold-200 hover:bg-gold-500/10",
                  )}
                >
                  {plan.cta}
                </button>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={120}>
          <p className="mt-8 text-center text-xs leading-7 text-slate-400">
            امکان پرداخت اقساطی برای دفاتر وکالت فراهم است — برای دریافت مشاوره، پیش‌فاکتور رسمی و
            نسخه دمو با شماره{" "}
            <a href={CONTACT.tel} dir="ltr" className="font-black text-gold-300">
              {CONTACT.phoneFa}
            </a>{" "}
            تماس بگیرید.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
