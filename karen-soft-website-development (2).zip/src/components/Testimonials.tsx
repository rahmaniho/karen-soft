import { Icon } from "./Icons";
import { Reveal, SectionHeading } from "./Reveal";
import { TESTIMONIALS } from "../data/site";

export function Testimonials() {
  return (
    <section className="relative overflow-hidden py-20 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="نظر کاربران"
          title={
            <>
              اعتماد <span className="gold-text">وکلای حرفه‌ای</span> سراسر کشور
            </>
          }
        />

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 110} className="h-full">
              <figure className="card-dark relative h-full rounded-2xl p-6">
                <span className="absolute top-4 left-5 font-serif text-6xl leading-none text-gold-500/20">
                  ”
                </span>
                <div className="mb-3 flex gap-1 text-gold-400">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Icon key={k} name="star" className="h-4 w-4 fill-gold-400" strokeWidth={1} />
                  ))}
                </div>
                <blockquote className="text-[13px] leading-8 text-slate-300/85">{t.text}</blockquote>
                <figcaption className="mt-5 flex items-center gap-3 border-t border-white/8 pt-4">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-gold-400 to-gold-600 text-sm font-black text-ink-950">
                    {t.name.charAt(0)}
                  </span>
                  <div>
                    <div className="text-sm font-black text-white">{t.name}</div>
                    <div className="text-[11px] text-slate-400">{t.role}</div>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
