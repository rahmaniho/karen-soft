const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** تبدیل ارقام لاتین به فارسی */
export function toFa(value: string | number): string {
  return String(value).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

/** جداکننده هزارگان + ارقام فارسی */
export function faMoney(value: number): string {
  return toFa(value.toLocaleString("en-US"));
}
